﻿namespace Sunglass_ecom.Models
{
    public class Orders
    {
        public int Id { get; set; } // Primary key
        public int UserId { get; set; }
        public string OrderNo { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal OrderTotal { get; set; }
        public string OrderStatus { get; set; }
        
    }
}
