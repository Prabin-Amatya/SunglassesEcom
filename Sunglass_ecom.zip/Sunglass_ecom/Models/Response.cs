﻿namespace Sunglass_ecom.Models
{
    public class Response
    {
       public int StatusCode { get; set; }
        public string statusMessage { get; set; }
    }
}
